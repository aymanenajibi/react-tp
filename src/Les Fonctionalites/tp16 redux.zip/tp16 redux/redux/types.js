export const AJOUTER = "AJOUTER";
export const RETIRER = "RETIRER";
export const ENREGISTRER = "ENREGISTRER";
